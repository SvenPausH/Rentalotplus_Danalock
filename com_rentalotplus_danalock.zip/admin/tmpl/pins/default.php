<?php
defined('_JEXEC') or die;

use Joomla\CMS\Session\Session;

$config   = $this->config;
$token    = Session::getFormToken();
$ajaxUrl  = 'index.php?option=com_rentalotplus_danalock&task=ajax.%s&format=json&' . $token . '=1';
?>
<style>
#dlPinModal {
    display: none; position: fixed; top:0; left:0; right:0; bottom:0;
    background: rgba(0,0,0,.5); z-index: 9999;
    align-items: center; justify-content: center; padding: 1rem;
}
#dlPinModal .modal-dialog { width:100%; max-width:560px; margin:0 auto; }
#dlPinModal .modal-content { background:#fff; border-radius:8px; box-shadow:0 4px 24px rgba(0,0,0,.2); }
</style>

<div class="container-fluid p-3">

  <!-- Schloss-Status -->
  <div class="card mb-3 border-0 shadow-sm">
    <div class="card-body d-flex align-items-center gap-3 py-2">
      <span class="fw-bold">🔒 Schloss-Status:</span>
      <span id="dl-lock-status" class="badge bg-secondary px-3 py-2">wird geladen…</span>
      <button class="btn btn-sm btn-outline-secondary" onclick="dlRefreshStatus()">↻ Aktualisieren</button>
      <span class="ms-auto text-muted small" id="dl-status-time"></span>
    </div>
  </div>

  <!-- Tabs -->
  <ul class="nav nav-tabs mb-0" id="dlTabs">
    <li class="nav-item">
      <button class="nav-link active" data-tab="bookings">📅 Buchungen &amp; PINs</button>
    </li>
    <li class="nav-item">
      <button class="nav-link" data-tab="slots">🔑 Alle PIN-Slots</button>
    </li>
    <li class="nav-item">
      <button class="nav-link" data-tab="log" id="dl-log-tab">📋 Debug-Log</button>
    </li>
  </ul>

  <div class="border border-top-0 rounded-bottom bg-white p-4 shadow-sm">

    <!-- TAB: Buchungen -->
    <div id="dl-tab-bookings">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="mb-0">Aktuelle &amp; kommende Buchungen</h5>
        <button class="btn btn-sm btn-outline-primary" onclick="dlLoadBookings()">↻ Aktualisieren</button>
      </div>
      <div id="dl-bload" class="text-center py-4 text-muted">
        <div class="spinner-border text-primary mb-2"></div><br>Buchungen werden geladen…
      </div>
      <div id="dl-bwrap" style="display:none">
        <table class="table table-hover table-sm align-middle">
          <thead class="table-light">
            <tr>
              <th>Gast</th><th>Anreise</th><th>Abreise</th><th>Status</th>
              <th>Slot</th><th>PIN</th><th>Check-in</th><th>Check-out</th><th class="text-end">Aktionen</th>
            </tr>
          </thead>
          <tbody id="dl-bbody"></tbody>
        </table>
      </div>
      <div id="dl-bempty" class="alert alert-info" style="display:none">Keine Buchungen gefunden.</div>
    </div>

    <!-- TAB: Slots -->
    <div id="dl-tab-slots" style="display:none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="mb-0">PIN-Slots am Schloss (1–20)</h5>
        <button class="btn btn-sm btn-outline-primary" onclick="dlLoadSlots()">↻ Vom Schloss laden</button>
      </div>
      <p class="text-muted small">Liest den aktuellen Stand direkt vom Schloss – dauert ca. 10 Sekunden.</p>
      <div id="dl-sload" style="display:none" class="text-center py-4 text-muted">
        <div class="spinner-border text-primary mb-2"></div><br>Wird geladen…
      </div>
      <div id="dl-swrap" style="display:none">
        <table class="table table-sm align-middle">
          <thead class="table-light">
            <tr><th>Slot</th><th>Status</th><th>PIN</th><th>Gast</th><th>Check-in</th><th>Check-out</th><th class="text-end">Aktion</th></tr>
          </thead>
          <tbody id="dl-sbody"></tbody>
        </table>
      </div>
    </div>


    <!-- TAB: Debug-Log -->
    <div id="dl-tab-log" style="display:none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="mb-0">Debug-Log <span class="badge bg-secondary" id="dl-log-count"></span></h5>
        <div class="d-flex gap-2">
          <button class="btn btn-sm btn-outline-primary" onclick="dlLoadLog()">↻ Aktualisieren</button>
          <button class="btn btn-sm btn-outline-danger" onclick="dlClearLog()">🗑 Log löschen</button>
        </div>
      </div>
      <div id="dl-log-disabled" class="alert alert-warning" style="display:none">
        Debug-Logging ist deaktiviert. Aktiviere es unter <strong>Optionen → Debug</strong>.
      </div>
      <div id="dl-log-loading" class="text-center py-4 text-muted" style="display:none">
        <div class="spinner-border text-primary mb-2"></div><br>Log wird geladen…
      </div>
      <div id="dl-log-empty" class="alert alert-info" style="display:none">Keine Log-Einträge vorhanden.</div>
      <div id="dl-log-wrap" style="display:none">
        <table class="table table-sm table-hover align-middle font-monospace" style="font-size:0.85em">
          <thead class="table-dark">
            <tr><th style="width:150px">Zeit</th><th style="width:120px">Level</th><th>Nachricht</th><th>Details</th></tr>
          </thead>
          <tbody id="dl-log-body"></tbody>
        </table>
      </div>
    </div>

    <div id="dl-alerts" class="mt-3"></div>
  </div>
</div>

<!-- Modal -->
<div id="dlPinModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header p-3 border-bottom">
        <h5 class="mb-0">🔑 PIN für Buchung festlegen</h5>
        <button class="btn-close" id="dlModalClose"></button>
      </div>
      <div class="modal-body p-3">
        <div class="alert alert-light border mb-3 py-2">
          <strong id="dlm-guest"></strong><br>
          <small class="text-muted" id="dlm-dates"></small>
        </div>
        <input type="hidden" id="dlm-bid">
        <input type="hidden" id="dlm-device">
        <div class="row g-3">
          <div class="col-4">
            <label class="form-label fw-semibold">PIN-Slot</label>
            <select class="form-select" id="dlm-slot">
              <?php for ($i = 1; $i <= 20; $i++): ?>
              <option value="<?= $i ?>"><?= $i ?></option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="col-8">
            <label class="form-label fw-semibold">PIN-Code</label>
            <div class="input-group">
              <input type="text" class="form-control font-monospace" id="dlm-pin"
                     pattern="\d{4,10}" maxlength="10" placeholder="z.B. 123456">
              <button class="btn btn-outline-secondary" type="button" onclick="dlGenPin()" title="Zufällig">⟳</button>
            </div>
            <div class="form-text">Nur Ziffern, 4–10 Stellen</div>
          </div>
          <div class="col-6">
            <label class="form-label fw-semibold">Check-in Zeit</label>
            <input type="time" class="form-control" id="dlm-checkin"
                   value="<?= htmlspecialchars($config->getDefaultCheckin()) ?>">
          </div>
          <div class="col-6">
            <label class="form-label fw-semibold">Check-out Zeit</label>
            <input type="time" class="form-control" id="dlm-checkout"
                   value="<?= htmlspecialchars($config->getDefaultCheckout()) ?>">
          </div>
        </div>
        <div id="dlm-msg" class="mt-3" style="display:none"></div>
      </div>
      <div class="modal-footer p-3 border-top d-flex justify-content-end gap-2">
        <button class="btn btn-secondary" id="dlModalCancel">Abbrechen</button>
        <button class="btn btn-primary" id="dlm-savebtn" onclick="dlSavePin()">💾 Speichern &amp; an Schloss senden</button>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
'use strict';

var AJAX = function(task) {
    return 'index.php?option=com_rentalotplus_danalock&task=ajax.' + task + '&format=json&<?= $token ?>=1';
};
var DEV = <?= json_encode($config->getDefaultDevice()) ?>;
var bookingCache = {};

// ── Tab-Umschaltung ──────────────────────────────────────────────────
function initTabs() {
    document.querySelectorAll('#dlTabs button[data-tab]').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('#dlTabs button').forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            var tab = btn.getAttribute('data-tab');
            document.getElementById('dl-tab-bookings').style.display = tab === 'bookings' ? '' : 'none';
            document.getElementById('dl-tab-slots').style.display    = tab === 'slots'    ? '' : 'none';
            document.getElementById('dl-tab-log').style.display      = tab === 'log'      ? '' : 'none';
            if (tab === 'log') dlLoadLog();
            if (tab === 'slots' && document.getElementById('dl-swrap').style.display === 'none') { dlLoadSlots(); }
        });
    });
}

// ── Buchungen laden ──────────────────────────────────────────────────
window.dlLoadBookings = function() {
    show('dl-bload'); hide('dl-bwrap'); hide('dl-bempty');
    dlPost(AJAX('get_bookings'), {}, function(data) {
        hide('dl-bload');
        if (!data.success) { dlAlert('Fehler: ' + (data.error || ''), 'danger'); return; }
        if (!data.bookings || !data.bookings.length) { show('dl-bempty'); return; }

        bookingCache = {};
        var tbody = document.getElementById('dl-bbody');
        tbody.innerHTML = '';

        data.bookings.forEach(function(b) {
            bookingCache[b.id] = b;

            var tr = document.createElement('tr');
            tr.innerHTML =
                '<td class="fw-semibold">' + esc(b.forenames + ' ' + b.surname) + '</td>' +
                '<td>' + fmtDate(b.date_from) + '</td>' +
                '<td>' + fmtDate(b.date_to)   + '</td>' +
                '<td>' + stateBadge(b.state)   + '</td>' +
                '<td>' + slotBadge(b.pin_identifier) + '</td>' +
                '<td>' + pinCell(b.pin_code)   + '</td>' +
                '<td>' + esc(b.checkin_time)   + '</td>' +
                '<td>' + esc(b.checkout_time)  + '</td>' +
                '<td class="text-end text-nowrap" id="dl-act-' + b.id + '"></td>';
            tbody.appendChild(tr);

            // Buttons per addEventListener – kein inline onclick
            var cell = document.getElementById('dl-act-' + b.id);

            var pinBtn = document.createElement('button');
            pinBtn.className = 'btn btn-sm btn-outline-primary';
            pinBtn.innerHTML = '✏️ PIN';
            pinBtn.setAttribute('data-bid', b.id);
            pinBtn.addEventListener('click', function() {
                openModal(parseInt(this.getAttribute('data-bid')));
            });
            cell.appendChild(pinBtn);

            if (b.pin_identifier) {
                var delBtn = document.createElement('button');
                delBtn.className = 'btn btn-sm btn-outline-danger ms-1';
                delBtn.innerHTML = '🗑';
                delBtn.title = 'PIN vom Schloss löschen';
                delBtn.setAttribute('data-bid', b.id);
                delBtn.setAttribute('data-slot', b.pin_identifier);
                delBtn.setAttribute('data-dev', b.device || DEV);
                delBtn.addEventListener('click', function() {
                    dlDelFromBooking(
                        parseInt(this.getAttribute('data-bid')),
                        parseInt(this.getAttribute('data-slot')),
                        this.getAttribute('data-dev'),
                        this
                    );
                });
                cell.appendChild(delBtn);
            }
        });

        show('dl-bwrap');
    });
};

// ── Modal ────────────────────────────────────────────────────────────
function openModal(bid) {
    var b = bookingCache[bid];
    if (!b) { dlAlert('Buchung nicht im Cache (ID ' + bid + ')', 'danger'); return; }
    document.getElementById('dlm-bid').value     = b.id;
    document.getElementById('dlm-device').value  = b.device || DEV;
    document.getElementById('dlm-slot').value    = b.pin_identifier || 1;
    document.getElementById('dlm-pin').value     = b.pin_code || '';
    document.getElementById('dlm-checkin').value = b.checkin_time  || '16:00';
    document.getElementById('dlm-checkout').value= b.checkout_time || '10:00';
    document.getElementById('dlm-guest').textContent = b.forenames + ' ' + b.surname;
    document.getElementById('dlm-dates').textContent =
        'Anreise: ' + fmtDate(b.date_from) + '  |  Abreise: ' + fmtDate(b.date_to);
    hide('dlm-msg');
    document.getElementById('dlPinModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}
function closeModal() {
    document.getElementById('dlPinModal').style.display = 'none';
    document.body.style.overflow = '';
}

window.dlGenPin = function() {
    var p = '';
    for (var i = 0; i < 6; i++) p += Math.floor(Math.random() * 10);
    document.getElementById('dlm-pin').value = p;
};

window.dlSavePin = function() {
    var pin = document.getElementById('dlm-pin').value.trim();
    if (!/^\d{4,10}$/.test(pin)) { setModalMsg('Ungültiger PIN – nur Ziffern, 4–10 Stellen', 'danger'); return; }

    var btn = document.getElementById('dlm-savebtn');
    btn.disabled = true;
    btn.textContent = 'Wird gesendet (ca. 10 Sek.)…';
    setModalMsg('Befehl wird ans Schloss gesendet, bitte warten…', 'info');

    dlPost(AJAX('save_booking_pin'), {
        booking_id:    document.getElementById('dlm-bid').value,
        identifier:    document.getElementById('dlm-slot').value,
        pin:           pin,
        checkin_time:  document.getElementById('dlm-checkin').value,
        checkout_time: document.getElementById('dlm-checkout').value
    }, function(data) {
        btn.disabled = false;
        btn.innerHTML = '💾 Speichern &amp; an Schloss senden';
        if (data.success && data.sent) {
            setModalMsg('✅ PIN gespeichert und am Schloss gesetzt!', 'success');
            setTimeout(function() { closeModal(); dlLoadBookings(); }, 1800);
        } else if (data.saved && !data.sent) {
            setModalMsg('⚠️ Gespeichert, aber Schloss hat nicht bestätigt. ' + (data.error || ''), 'warning');
            dlLoadBookings();
        } else {
            setModalMsg('❌ ' + (data.error || JSON.stringify(data)), 'danger');
        }
    });
};

// ── PIN löschen aus Buchungszeile ────────────────────────────────────
window.dlDelFromBooking = function(bid, slot, device, btn) {
    if (!confirm('PIN Slot ' + slot + ' wirklich vom Schloss löschen?')) return;
    btn.disabled = true;
    dlPost(AJAX('delete_pin'), {identifier: slot, device: device}, function(data) {
        btn.disabled = false;
        if (data.success) { dlAlert('Slot ' + slot + ' gelöscht.', 'success'); dlLoadBookings(); }
        else dlAlert('Fehler: ' + (data.error || ''), 'danger');
    });
};

// ── Slots laden ──────────────────────────────────────────────────────
window.dlLoadSlots = function() {
    show('dl-sload'); hide('dl-swrap');
    dlPost(AJAX('get_pins'), {device: DEV}, function(data) {
        hide('dl-sload');
        if (!data.success) { dlAlert('Fehler: ' + (data.error || ''), 'danger'); return; }
        var pins  = (data.data && data.data.result && data.data.result.pin_codes) || [];
        var dbMap = data.db_pins || {};
        var tbody = document.getElementById('dl-sbody');
        tbody.innerHTML = '';
        pins.forEach(function(p) {
            var active = p.status === 2;
            var db     = dbMap[p.identifier] || {};
            var tr = document.createElement('tr');
            tr.innerHTML =
                '<td><strong>Slot ' + p.identifier + '</strong></td>' +
                '<td>' + (active ? '<span class="text-success fw-semibold">● Aktiv</span>' : '<span class="text-muted">○ Frei</span>') + '</td>' +
                '<td>' + (active ? '<code>' + esc(p.digits) + '</code>' : '–') + '</td>' +
                '<td>' + (db.guest_name ? esc(db.guest_name) : '<span class="text-muted">–</span>') + '</td>' +
                '<td>' + (db.checkin_time  || '–') + '</td>' +
                '<td>' + (db.checkout_time || '–') + '</td>' +
                '<td class="text-end"></td>';
            tbody.appendChild(tr);
            var delBtn = document.createElement('button');
            delBtn.className = 'btn btn-sm btn-outline-danger';
            delBtn.innerHTML = '🗑 Löschen';
            if (!active) delBtn.disabled = true;
            delBtn.setAttribute('data-slot', p.identifier);
            delBtn.addEventListener('click', function() {
                dlDelSlot(parseInt(this.getAttribute('data-slot')), this);
            });
            tr.querySelector('td:last-child').appendChild(delBtn);
        });
        show('dl-swrap');
    });
};

window.dlDelSlot = function(slot, btn) {
    if (!confirm('Slot ' + slot + ' löschen?')) return;
    btn.disabled = true;
    dlPost(AJAX('delete_pin'), {identifier: slot, device: DEV}, function(data) {
        btn.disabled = false;
        if (data.success) { dlAlert('Slot ' + slot + ' gelöscht.', 'success'); dlLoadSlots(); }
        else dlAlert('Fehler: ' + (data.error || ''), 'danger');
    });
};

// ── Schloss-Status ───────────────────────────────────────────────────
window.dlRefreshStatus = function() {
    var el = document.getElementById('dl-lock-status');
    el.className = 'badge bg-secondary px-3 py-2';
    el.textContent = '…';
    dlPost(AJAX('lock_status'), {device: DEV}, function(data) {
        document.getElementById('dl-status-time').textContent = 'Stand: ' + new Date().toLocaleTimeString('de-DE');
        if (!data.success) { el.className = 'badge bg-danger px-3 py-2'; el.textContent = 'Fehler'; return; }
        var state = (data.data && data.data.result && data.data.result.state) || '?';
        el.textContent = state === 'Locked' ? '🔒 Gesperrt' : state === 'Unlocked' ? '🔓 Offen' : state;
        el.className = 'badge px-3 py-2 ' + (state === 'Locked' ? 'bg-success' : state === 'Unlocked' ? 'bg-warning text-dark' : 'bg-secondary');
    });
};

// ── Hilfsfunktionen ──────────────────────────────────────────────────
function dlPost(url, data, cb) {
    var body = Object.keys(data).map(function(k) {
        return encodeURIComponent(k) + '=' + encodeURIComponent(data[k]);
    }).join('&');
    fetch(url, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:body})
        .then(function(r) { return r.json(); })
        .then(cb)
        .catch(function(e) { dlAlert('Netzwerkfehler: ' + e.message, 'danger'); });
}
function dlAlert(msg, type) {
    var d = document.createElement('div');
    d.className = 'alert alert-' + type + ' alert-dismissible fade show';
    d.innerHTML = msg + '<button type="button" class="btn-close" onclick="this.parentNode.remove()"></button>';
    document.getElementById('dl-alerts').prepend(d);
    setTimeout(function() { if (d.parentNode) d.remove(); }, 7000);
}
function setModalMsg(msg, type) {
    var el = document.getElementById('dlm-msg');
    el.className = 'alert alert-' + type;
    el.textContent = msg;
    el.style.display = 'block';
}
function stateBadge(s) {
    return s == 1
        ? '<span class="badge" style="background:#198754">Gebucht</span>'
        : '<span class="badge" style="background:#ffc107;color:#000">Reserviert</span>';
}
function slotBadge(s) {
    return s ? '<span class="badge bg-primary">Slot&nbsp;' + s + '</span>' : '<span class="text-muted">–</span>';
}
function pinCell(p) {
    return p ? '<code class="fs-6">' + esc(p) + '</code>' : '<span class="text-muted fst-italic">nicht gesetzt</span>';
}
function show(id) { var e = document.getElementById(id); if (e) e.style.display = ''; }
function hide(id) { var e = document.getElementById(id); if (e) e.style.display = 'none'; }
function esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function fmtDate(d) {
    if (!d) return '–';
    var p = d.split('-');
    return p.length === 3 ? p[2] + '.' + p[1] + '.' + p[0] : d;
}

// ── Init ─────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
    initTabs();
    dlLoadBookings();
    dlRefreshStatus();
    document.getElementById('dlModalClose').addEventListener('click', closeModal);
    document.getElementById('dlModalCancel').addEventListener('click', closeModal);
    document.getElementById('dlPinModal').addEventListener('click', function(e) {
        if (e.target === this) closeModal();
    });
});


// ── Debug-Log ────────────────────────────────────────────────────────
window.dlLoadLog = function() {
    show('dl-log-loading'); hide('dl-log-wrap'); hide('dl-log-empty'); hide('dl-log-disabled');
    dlPost(AJAX('get_log'), {limit: 100}, function(data) {
        hide('dl-log-loading');
        if (!data.success) { dlAlert('Log-Fehler: ' + (data.error || ''), 'danger'); return; }
        var entries = data.entries || [];
        document.getElementById('dl-log-count').textContent = entries.length;
        if (!entries.length) {
            show('dl-log-disabled');
            return;
        }
        var tbody = document.getElementById('dl-log-body');
        tbody.innerHTML = '';
        entries.forEach(function(e) {
            var levelClass = {
                'AUTH_ERROR':'danger','EXECUTE_ERROR':'danger',
                'AUTH_OK':'success','POLL_RESULT':'info',
                'EXECUTE':'primary','JOB_ID':'secondary',
                'AUTH':'secondary'
            }[e.level] || 'light';
            var ctx = '';
            if (e.context) {
                try {
                    var parsed = JSON.parse(e.context);
                    ctx = '<pre class="mb-0 text-wrap" style="font-size:0.8em;max-height:120px;overflow-y:auto">'
                        + esc(JSON.stringify(parsed, null, 2)) + '</pre>';
                } catch(x) { ctx = esc(e.context); }
            }
            var tr = document.createElement('tr');
            tr.innerHTML =
                '<td class="text-nowrap">' + esc(e.created_at) + '</td>' +
                '<td><span class="badge bg-' + levelClass + '">' + esc(e.level) + '</span></td>' +
                '<td>' + esc(e.message) + '</td>' +
                '<td>' + ctx + '</td>';
            tbody.appendChild(tr);
        });
        show('dl-log-wrap');
    });
};

window.dlClearLog = function() {
    if (!confirm('Log wirklich löschen?')) return;
    dlPost(AJAX('clear_log'), {}, function(data) {
        if (data.success) { dlAlert('Log gelöscht.', 'success'); dlLoadLog(); }
        else dlAlert('Fehler: ' + (data.error || ''), 'danger');
    });
};

})();
</script>
