<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\Component\RentalotplusDanalock\Administrator\Helper\DanalockHelper;
use Joomla\Component\RentalotplusDanalock\Administrator\Helper\DanalockConfig;

class AjaxController extends BaseController
{
    public function execute($task): void
    {
        $app    = Factory::getApplication();
        $config = DanalockConfig::getInstance();
        $helper = new DanalockHelper($config);

        // CSRF-Schutz
        if (!$this->checkToken('request')) {
            $this->sendJson(['success' => false, 'error' => 'Ungültiges Token']);
            return;
        }

        // Task kommt als "ajax.get_bookings" – Prefix "ajax." entfernen
        $action = str_replace('ajax.', '', $task);

        switch ($action) {
            case 'get_bookings':
                $this->sendJson($helper->getBookings());
                break;
            case 'save_booking_pin':
                $input      = $app->input;
                $this->sendJson($helper->saveBookingPin(
                    $input->getInt('booking_id', 0),
                    $input->getInt('identifier', 0),
                    $input->get('pin', '', 'string'),
                    $input->get('checkin_time', '16:00', 'string'),
                    $input->get('checkout_time', '10:00', 'string')
                ));
                break;
            case 'delete_pin':
                $this->sendJson($helper->deletePin(
                    $app->input->getInt('identifier', 0),
                    $app->input->get('device', '', 'string')
                ));
                break;
            case 'get_pins':
                $this->sendJson($helper->getPins(
                    $app->input->get('device', '', 'string')
                ));
                break;
            case 'lock_status':
                $this->sendJson($helper->getLockStatus(
                    $app->input->get('device', '', 'string')
                ));
                break;
            case 'get_log':
                $limit = $app->input->getInt('limit', 50);
                $this->sendJson($helper->getLogEntries($limit));
                break;
            case 'clear_log':
                $this->sendJson($helper->clearLog());
                break;
            default:
                $this->sendJson(['success' => false, 'error' => 'Unbekannter Task: ' . $action]);
        }
    }

    private function sendJson(array $data): void
    {
        $app = Factory::getApplication();
        $app->setHeader('Content-Type', 'application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        $app->close();
    }
}
