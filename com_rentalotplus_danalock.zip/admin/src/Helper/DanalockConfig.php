<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;

class DanalockConfig
{
    private static ?self $instance = null;
    private \Joomla\Registry\Registry $params;
    private array $unitMapping = [];

    private function __construct()
    {
        $this->params = ComponentHelper::getParams('com_rentalotplus_danalock');

        foreach (explode("\n", $this->params->get('unit_mapping', '')) as $line) {
            $line = trim($line);
            if ($line !== '' && strpos($line, ':') !== false) {
                $pos    = strpos($line, ':');
                $unitId = trim(substr($line, 0, $pos));
                $mac    = trim(substr($line, $pos + 1));
                if ($unitId !== '' && $mac !== '') {
                    $this->unitMapping[$unitId] = $mac;
                }
            }
        }
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    // Generischer Param-Zugriff für den Helper
    public function getParam(string $key, $default = null)
    {
        return $this->params->get($key, $default);
    }

    public function getEmail(): string           { return $this->params->get('danalock_email', ''); }
    public function getPassword(): string        { return $this->params->get('danalock_password', ''); }
    public function getDefaultDevice(): string   { return $this->params->get('danalock_device', ''); }
    public function getDefaultCheckin(): string  { return $this->params->get('default_checkin_time', '16:00'); }
    public function getDefaultCheckout(): string { return $this->params->get('default_checkout_time', '10:00'); }
    public function getUnitMapping(): array      { return $this->unitMapping; }
    public function isDebugEnabled(): bool       { return (bool) $this->params->get('debug_enabled', 0); }

    public function getDeviceForUnit(int $unitId): string
    {
        return $this->unitMapping[$unitId] ?? $this->getDefaultDevice();
    }
}
