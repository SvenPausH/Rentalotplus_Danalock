<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;

class DanalockHelper
{
    const TOKEN_URL  = 'https://api.danalock.com/oauth2/token';
    const BRIDGE_URL = 'https://bridge.danalockservices.com/bridge/v1/execute';
    const POLL_URL   = 'https://bridge.danalockservices.com/bridge/v1/poll';
    const POLL_WAIT  = 7;
    const DB_LOG_TABLE = '#__rentalot_plus_danalock_log';

    private DanalockConfig $config;
    private bool $debugEnabled;
    private int  $debugMax;

    public function __construct(DanalockConfig $config)
    {
        $this->config       = $config;
        $this->debugEnabled = (bool) $config->getParam('debug_enabled', 0);
        $this->debugMax     = (int)  $config->getParam('debug_max_entries', 50);
    }

    // -------------------------------------------------------------------------
    // Öffentliche API-Methoden
    // -------------------------------------------------------------------------

    public function getBookings(): array
    {
        // Abgelaufene PIN-Slots automatisch freigeben
        $this->releaseExpiredPins();

        try {
            $db    = Factory::getDbo();
            $today = date('Y-m-d');

            $query = $db->getQuery(true)
                ->select(['b.id', 'b.unit_id', 'b.date_from', 'b.date_to',
                          'b.state', 'b.forenames', 'b.surname'])
                ->from($db->quoteName('#__rentalot_plus_bookings', 'b'))
                ->where('b.state IN (0, 1)')
                ->where('b.date_to >= ' . $db->quote($today))
                ->order('b.date_from ASC');

            $bookings = $db->setQuery($query)->loadAssocList();

            $pinData = $db->setQuery(
                $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName('#__rentalot_plus_danalock_pins'))
            )->loadAssocList('booking_id');

            foreach ($bookings as &$b) {
                $bid = $b['id'];
                if (isset($pinData[$bid])) {
                    $b['pin_identifier'] = (int)$pinData[$bid]['pin_identifier'];
                    $b['pin_code']       = $pinData[$bid]['pin_code'];
                    $b['checkin_time']   = $pinData[$bid]['checkin_time'];
                    $b['checkout_time']  = $pinData[$bid]['checkout_time'];
                } else {
                    $b['pin_identifier'] = null;
                    $b['pin_code']       = '';
                    $b['checkin_time']   = $this->config->getDefaultCheckin();
                    $b['checkout_time']  = $this->config->getDefaultCheckout();
                }
                $b['device'] = $this->config->getDeviceForUnit((int)$b['unit_id']);
            }

                // Belegte Slots sammeln (für Modal-Auswahl)
            $usedSlots = [];
            foreach ($bookings as $b) {
                if ($b['pin_identifier']) {
                    $usedSlots[$b['id']] = $b['pin_identifier'];
                }
            }

            return ['success' => true, 'bookings' => $bookings, 'used_slots' => $usedSlots];

        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function saveBookingPin(int $bookingId, int $identifier, string $pin,
                                   string $checkin, string $checkout): array
    {
        if ($bookingId <= 0 || $identifier < 1 || $identifier > 20) {
            return ['success' => false, 'error' => 'Ungültige Parameter'];
        }
        if (!preg_match('/^\d{4,10}$/', $pin)) {
            return ['success' => false, 'error' => 'Ungültiger PIN (4–10 Ziffern)'];
        }

        // In Datenbank speichern
        try {
            $db  = Factory::getDbo();
            $obj = (object)[
                'booking_id'     => $bookingId,
                'pin_identifier' => $identifier,
                'pin_code'       => $pin,
                'checkin_time'   => $checkin,
                'checkout_time'  => $checkout,
                'last_updated'   => date('Y-m-d H:i:s'),
            ];

            $existing = $db->setQuery(
                $db->getQuery(true)->select('id')
                    ->from($db->quoteName('#__rentalot_plus_danalock_pins'))
                    ->where('booking_id = ' . $bookingId)
            )->loadResult();

            if ($existing) { $obj->id = $existing; $db->updateObject('#__rentalot_plus_danalock_pins', $obj, 'id'); }
            else            { $db->insertObject('#__rentalot_plus_danalock_pins', $obj); }

        } catch (\Exception $e) {
            return ['success' => false, 'error' => 'DB-Fehler: ' . $e->getMessage()];
        }

        // Gerät ermitteln
        $device = $this->config->getDefaultDevice();
        try {
            $db     = Factory::getDbo();
            $unitId = $db->setQuery(
                $db->getQuery(true)->select('unit_id')
                    ->from($db->quoteName('#__rentalot_plus_bookings'))
                    ->where('id = ' . $bookingId)
            )->loadResult();
            if ($unitId) $device = $this->config->getDeviceForUnit((int)$unitId);
        } catch (\Exception $e) {}

        // PIN ans Schloss senden
        $token = $this->getOAuthToken();
        if (!$token) {
            return ['success' => true, 'saved' => true, 'sent' => false,
                    'error' => 'Gespeichert, aber Token-Fehler'];
        }

        // Schritt 1: Bestehende Zeitregel löschen (falls vorhanden)
        $this->deleteTimeRestrictionRule($token, $device, $identifier);

        // Schritt 2: PIN setzen
        $result  = $this->executeBridgeCommand(
            $token, $device, 'afi.pin-codes.set-pin-code',
            [(string)$identifier, 'Enabled', $pin],
            'PIN setzen: Booking #' . $bookingId . ', Slot ' . $identifier
        );
        $success = isset($result['result']['afi_status']) && $result['result']['afi_status'] === 0;

        // Schritt 3: Zeitregel erstellen wenn Zeiten angegeben
        $timeResult = null;
        if ($checkin && $checkout) {
            // Buchungsdaten (Datum) aus DB laden
            $dateFrom = null;
            $dateTo   = null;
            try {
                $db       = Factory::getDbo();
                $booking  = $db->setQuery(
                    $db->getQuery(true)
                        ->select(['date_from', 'date_to'])
                        ->from($db->quoteName('#__rentalot_plus_bookings'))
                        ->where('id = ' . $bookingId)
                )->loadObject();
                $dateFrom = $booking->date_from ?? null;
                $dateTo   = $booking->date_to   ?? null;
            } catch (\Exception $e) {}

            if ($dateFrom && $dateTo) {
                $startArg   = $this->formatTimeArg($dateFrom, $checkin);
                $endArg     = $this->formatTimeArg($dateTo,   $checkout);
                $timeResult = $this->executeBridgeCommand(
                    $token, $device, 'afi.pin-codes.create-time-restriction-rule',
                    [(string)$identifier, $startArg, $endArg],
                    'Zeitregel: Slot ' . $identifier . ' ' . $startArg . ' bis ' . $endArg
                );
            }
        }

        return [
            'success'     => true,
            'saved'       => true,
            'sent'        => $success,
            'time_result' => $timeResult,
            'data'        => $result,
        ];
    }

    /**
     * Formatiert ein Datum+Zeit als Danalock-Zeitargument.
     * Format laut API: "YYYY M D HH:MM DISABLED 00:00"
     * Beispiel: "2026 6 13 15:46 DISABLED 00:00"
     *
     * @param string $date  Datum im Format Y-m-d (aus der Buchungstabelle)
     * @param string $time  Uhrzeit im Format HH:MM
     */
    private function formatTimeArg(string $date, string $time): string
    {
        try {
            $d     = new \DateTime($date);
            $year  = $d->format('Y');
            $month = (int)$d->format('n'); // ohne fuehrende Null: 6 nicht 06
            $day   = (int)$d->format('j'); // ohne fuehrende Null: 13 nicht 13
            return $year . ' ' . $month . ' ' . $day . ' ' . $time . ' DISABLED 00:00';
        } catch (\Exception $e) {
            // Fallback: heutiges Datum
            $now = new \DateTime();
            return $now->format('Y') . ' ' . (int)$now->format('n') . ' ' . (int)$now->format('j') . ' ' . $time . ' DISABLED 00:00';
        }
    }

    /**
     * Löscht alle bestehenden Zeitregeln für einen Slot.
     * Fragt zuerst die Regeln ab, extrahiert den 'handle' und löscht ihn.
     * Die Regel-ID heißt beim Danalock 'handle'.
     */
    private function deleteTimeRestrictionRule(string $token, string $device, int $identifier): void
    {
        try {
            $result = $this->executeBridgeCommand(
                $token, $device,
                'afi.pin-codes.get-time-restriction-rules',
                [(string)$identifier],
                'Zeitregeln abfragen: Slot ' . $identifier
            );

            // Regeln aus der verschachtelten Antwort extrahieren
            $rules = $result['result']['result']['rules']
                  ?? $result['result']['rules']
                  ?? [];

            foreach ($rules as $rule) {
                $handle = $rule['handle'] ?? null;
                if ($handle !== null) {
                    $this->executeBridgeCommand(
                        $token, $device,
                        'afi.pin-codes.delete-time-restriction-rule',
                        [(int)$handle],
                        'Zeitregel löschen: Handle ' . $handle
                    );
                }
            }
        } catch (\Exception $e) {
            // Keine Regel vorhanden oder Fehler – kein Problem, weiter mit PIN setzen
        }
    }

    /**
     * Gibt einen PIN-Slot in der Joomla-DB frei.
     * Das Schloss wird NICHT verändert – der PIN bleibt aktiv
     * und wird beim nächsten Gast einfach überschrieben.
     */
    public function deletePin(int $bookingId): array
    {
        if ($bookingId <= 0) {
            return ['success' => false, 'error' => 'Ungültige Buchungs-ID'];
        }

        try {
            $db = Factory::getDbo();
            $db->setQuery(
                $db->getQuery(true)
                    ->delete($db->quoteName('#__rentalot_plus_danalock_pins'))
                    ->where('booking_id = ' . $bookingId)
            )->execute();

            return ['success' => true, 'message' => 'Slot freigegeben'];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Prüft abgelaufene PIN-Zuordnungen und gibt Slots automatisch frei.
     * Wird beim Laden der Buchungen aufgerufen.
     * Ein Slot gilt als abgelaufen wenn date_to + checkout_time in der Vergangenheit liegt.
     */
    public function releaseExpiredPins(): void
    {
        try {
            $db  = Factory::getDbo();
            $now = new \DateTime();

            $rows = $db->setQuery(
                $db->getQuery(true)
                    ->select(['p.id', 'p.booking_id', 'p.checkout_time', 'b.date_to'])
                    ->from($db->quoteName('#__rentalot_plus_danalock_pins', 'p'))
                    ->join('INNER', $db->quoteName('#__rentalot_plus_bookings', 'b') . ' ON b.id = p.booking_id')
            )->loadAssocList();

            foreach ($rows as $row) {
                // Abreisezeitpunkt = date_to + checkout_time
                try {
                    $checkoutDt = new \DateTime($row['date_to'] . ' ' . $row['checkout_time']);
                    if ($checkoutDt < $now) {
                        // Abgelaufen – Slot freigeben
                        $db->setQuery(
                            $db->getQuery(true)
                                ->delete($db->quoteName('#__rentalot_plus_danalock_pins'))
                                ->where('id = ' . (int)$row['id'])
                        )->execute();
                    }
                } catch (\Exception $e) {}
            }
        } catch (\Exception $e) {}
    }

    public function getPins(string $device = ''): array
    {
        if (empty($device)) $device = $this->config->getDefaultDevice();

        $token = $this->getOAuthToken();
        if (!$token) return ['success' => false, 'error' => 'Token-Fehler'];

        $result = $this->executeBridgeCommand(
            $token, $device, 'afi.pin-codes.get-pin-codes', ['20'],
            'Alle PINs auslesen'
        );

        // DB-Daten dazu laden
        $dbPins = [];
        try {
            $db   = Factory::getDbo();
            $rows = $db->setQuery(
                $db->getQuery(true)
                    ->select(['p.pin_identifier', 'p.checkin_time', 'p.checkout_time',
                               'b.forenames', 'b.surname'])
                    ->from($db->quoteName('#__rentalot_plus_danalock_pins', 'p'))
                    ->join('LEFT', $db->quoteName('#__rentalot_plus_bookings', 'b')
                           . ' ON b.id = p.booking_id')
            )->loadAssocList();
            foreach ($rows as $row) {
                $dbPins[(int)$row['pin_identifier']] = [
                    'guest_name'    => trim($row['forenames'] . ' ' . $row['surname']),
                    'checkin_time'  => $row['checkin_time'],
                    'checkout_time' => $row['checkout_time'],
                ];
            }
        } catch (\Exception $e) {}

        return ['success' => true, 'data' => $result, 'db_pins' => $dbPins];
    }

    public function getLockStatus(string $device = ''): array
    {
        if (empty($device)) $device = $this->config->getDefaultDevice();

        $token = $this->getOAuthToken();
        if (!$token) return ['success' => false, 'error' => 'Token-Fehler'];

        $result = $this->executeBridgeCommand(
            $token, $device, 'afi.lock.get-state', [],
            'Schloss-Status abfragen'
        );
        return ['success' => true, 'data' => $result];
    }

    // -------------------------------------------------------------------------
    // Log-Einträge für die UI
    // -------------------------------------------------------------------------

    public function getLogEntries(int $limit = 50): array
    {
        try {
            $db   = Factory::getDbo();
            $rows = $db->setQuery(
                $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName(self::DB_LOG_TABLE))
                    ->order('id DESC'),
                0, $limit
            )->loadAssocList();
            return ['success' => true, 'entries' => $rows];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function clearLog(): array
    {
        try {
            $db = Factory::getDbo();
            $db->setQuery('TRUNCATE TABLE ' . $db->quoteName(str_replace('#__', $db->getPrefix(), self::DB_LOG_TABLE)))->execute();
            return ['success' => true];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // -------------------------------------------------------------------------
    // Danalock API intern
    // -------------------------------------------------------------------------

    public function getOAuthToken(): ?string
    {
        $session   = Factory::getApplication()->getSession();
        $cached    = $session->get('danalock_token');
        $cachedExp = $session->get('danalock_token_exp', 0);

        if ($cached && time() < $cachedExp - 60) {
            return $cached;
        }

        $postData = http_build_query([
            'grant_type'    => 'password',
            'username'      => $this->config->getEmail(),
            'password'      => $this->config->getPassword(),
            'client_id'     => 'danalock-web',
            'client_secret' => '',
            'scope'         => '',
        ]);

        $this->dbLog('AUTH', 'Token-Anfrage', ['username' => $this->config->getEmail()]);

        $response = $this->httpPost(self::TOKEN_URL, $postData,
            ['Content-Type: application/x-www-form-urlencoded']);

        if (!$response || !isset($response['access_token'])) {
            $this->dbLog('AUTH_ERROR', 'Token-Anfrage fehlgeschlagen', $response ?? []);
            Log::add('Danalock Token-Fehler: ' . json_encode($response), Log::ERROR, 'com_rentalotplus_danalock');
            return null;
        }

        $token   = $response['access_token'];
        $expires = $response['expires_in'] ?? 3600;
        $session->set('danalock_token', $token);
        $session->set('danalock_token_exp', time() + $expires);

        $this->dbLog('AUTH_OK', 'Token erhalten', ['expires_in' => $expires]);
        return $token;
    }

    private function executeBridgeCommand(string $token, string $device,
                                          string $operation, array $arguments,
                                          string $description = ''): array
    {
        $body = ['device' => $device, 'operation' => $operation];
        if (!empty($arguments)) $body['arguments'] = $arguments;

        $this->dbLog('EXECUTE', $description ?: $operation, [
            'device'    => $device,
            'operation' => $operation,
            'arguments' => $arguments,
        ]);

        $response = $this->httpPost(self::BRIDGE_URL, json_encode($body), [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ]);

        if (!$response || !isset($response['id'])) {
            $this->dbLog('EXECUTE_ERROR', 'Keine Job-ID erhalten', ['response' => $response]);
            return ['error' => 'Keine Job-ID erhalten', 'raw' => $response];
        }

        $jobId = $response['id'];
        $this->dbLog('JOB_ID', 'Job-ID erhalten, warte ' . self::POLL_WAIT . 's', ['job_id' => $jobId]);

        sleep(self::POLL_WAIT);

        $poll = $this->httpPost(self::POLL_URL, json_encode(['id' => $jobId]), [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ]);

        $this->dbLog('POLL_RESULT', $description ?: $operation, [
            'job_id' => $jobId,
            'result' => $poll,
        ]);

        return $poll ?? ['error' => 'Poll-Antwort leer', 'job_id' => $jobId];
    }

    private function httpPost(string $url, $body, array $headers): ?array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $raw      = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($error) {
            Log::add('Danalock cURL-Fehler: ' . $error, Log::ERROR, 'com_rentalotplus_danalock');
            return null;
        }

        $decoded = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            Log::add('Danalock JSON-Fehler (HTTP ' . $httpCode . '): ' . $raw, Log::ERROR, 'com_rentalotplus_danalock');
            return null;
        }

        return $decoded;
    }

    // -------------------------------------------------------------------------
    // Internes Debug-Logging in Datenbank
    // -------------------------------------------------------------------------

    private function dbLog(string $level, string $message, array $context = []): void
    {
        if (!$this->debugEnabled) return;

        try {
            $db  = Factory::getDbo();
            $obj = (object)[
                'created_at' => date('Y-m-d H:i:s'),
                'level'      => $level,
                'message'    => $message,
                'context'    => json_encode($context, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
            ];
            $db->insertObject(self::DB_LOG_TABLE, $obj);

            // Alte Einträge löschen wenn Maximum erreicht
            $count = $db->setQuery(
                'SELECT COUNT(*) FROM ' . $db->quoteName(self::DB_LOG_TABLE)
            )->loadResult();

            if ($count > $this->debugMax) {
                $db->setQuery(
                    'DELETE FROM ' . $db->quoteName(self::DB_LOG_TABLE) .
                    ' ORDER BY id ASC LIMIT ' . ($count - $this->debugMax)
                )->execute();
            }
        } catch (\Exception $e) {
            // Log-Fehler dürfen die Hauptfunktion nicht unterbrechen
        }
    }
}
