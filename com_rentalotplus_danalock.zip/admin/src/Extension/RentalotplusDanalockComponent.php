<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Extension\MVCComponent;
use Joomla\CMS\MVC\Factory\MVCFactoryServiceTrait;

class RentalotplusDanalockComponent extends MVCComponent
{
    use MVCFactoryServiceTrait;
}
