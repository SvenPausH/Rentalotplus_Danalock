CREATE TABLE IF NOT EXISTS `#__rentalot_plus_danalock_pins` (
    `id`             INT NOT NULL AUTO_INCREMENT,
    `booking_id`     INT NOT NULL,
    `pin_identifier` TINYINT NOT NULL DEFAULT 1,
    `pin_code`       VARCHAR(10) NOT NULL DEFAULT '',
    `checkin_time`   VARCHAR(5)  NOT NULL DEFAULT '16:00',
    `checkout_time`  VARCHAR(5)  NOT NULL DEFAULT '10:00',
    `last_updated`   DATETIME    NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_booking` (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rentalot_plus_danalock_log` (
    `id`         INT NOT NULL AUTO_INCREMENT,
    `created_at` DATETIME NOT NULL,
    `level`      VARCHAR(30) NOT NULL DEFAULT '',
    `message`    VARCHAR(255) NOT NULL DEFAULT '',
    `context`    MEDIUMTEXT,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
