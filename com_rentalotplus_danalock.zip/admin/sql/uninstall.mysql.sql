DROP TABLE IF EXISTS `#__rentalot_plus_danalock_pins`;
DROP TABLE IF EXISTS `#__rentalot_plus_danalock_log`;
