<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;

class Com_Rentalotplus_DanalockInstallerScript
{
    private array $savedParams = [];
    private ?int  $savedMenuId = null;

    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type !== 'update') return true;

        try {
            $db = Factory::getDbo();

            // Parameter sichern
            $raw = $db->setQuery(
                $db->getQuery(true)
                    ->select('params')
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus_danalock'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
            )->loadResult();
            if ($raw) $this->savedParams = json_decode($raw, true) ?? [];

            // Bestehende Menü-ID sichern
            $extId = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select('extension_id')
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus_danalock'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
            )->loadResult();

            if ($extId) {
                $this->savedMenuId = (int) $db->setQuery(
                    $db->getQuery(true)
                        ->select('id')
                        ->from($db->quoteName('#__menu'))
                        ->where($db->quoteName('component_id') . ' = ' . $extId)
                        ->where($db->quoteName('client_id') . ' = 1')
                )->loadResult();
            }
        } catch (\Exception $e) {}

        return true;
    }

    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        $app = Factory::getApplication();

        try {
            $db = Factory::getDbo();

            // 1. Parameter wiederherstellen
            if ($type === 'update' && !empty($this->savedParams)) {
                $db->setQuery(
                    'UPDATE ' . $db->quoteName('#__extensions')
                    . ' SET ' . $db->quoteName('params') . ' = ' . $db->quote(json_encode($this->savedParams))
                    . ' WHERE ' . $db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus_danalock')
                    . ' AND ' . $db->quoteName('type') . ' = ' . $db->quote('component')
                )->execute();
            }

            // 2. Doppelte Menüeinträge entfernen
            if ($type === 'update' && $this->savedMenuId) {
                $extId = (int) $db->setQuery(
                    $db->getQuery(true)
                        ->select('extension_id')
                        ->from($db->quoteName('#__extensions'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus_danalock'))
                        ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
                )->loadResult();

                if ($extId) {
                    $dupIds = $db->setQuery(
                        $db->getQuery(true)
                            ->select('id')
                            ->from($db->quoteName('#__menu'))
                            ->where($db->quoteName('component_id') . ' = ' . $extId)
                            ->where($db->quoteName('client_id') . ' = 1')
                            ->where($db->quoteName('id') . ' != ' . $this->savedMenuId)
                    )->loadColumn();

                    foreach ($dupIds as $dupId) {
                        $db->setQuery('DELETE FROM ' . $db->quoteName('#__menu') . ' WHERE id = ' . (int)$dupId)->execute();
                    }
                    if (!empty($dupIds)) {
                        try { (new \Joomla\CMS\Table\Menu($db))->rebuild(); } catch (\Exception $e) {}
                    }
                }
            }

            // 3. Menüpunkt unter Rentalot Plus einordnen
            $this->fixMenuParent($db);

        } catch (\Exception $e) {
            $app->enqueueMessage('Danalock Installer Fehler: ' . $e->getMessage(), 'error');
        }

        return true;
    }

    private function fixMenuParent($db): void
    {
        try {
            $extId = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select('extension_id')
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus_danalock'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
            )->loadResult();

            if (!$extId) return;

            $ourMenu = $db->setQuery(
                $db->getQuery(true)
                    ->select(['id', 'alias', 'parent_id'])
                    ->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('component_id') . ' = ' . $extId)
                    ->where($db->quoteName('client_id') . ' = 1')
            )->loadObject();

            if (!$ourMenu) return;

            $parentId = $this->findParentId($db);
            if (!$parentId || (int)$ourMenu->parent_id === $parentId) return;

            $parentPath = (string) $db->setQuery(
                $db->getQuery(true)->select('path')->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('id') . ' = ' . $parentId)
            )->loadResult();

            $db->setQuery(
                'UPDATE ' . $db->quoteName('#__menu')
                . ' SET ' . $db->quoteName('parent_id') . ' = ' . $parentId
                . ', ' . $db->quoteName('level') . ' = 2'
                . ', ' . $db->quoteName('path') . ' = ' . $db->quote(trim($parentPath, '/') . '/' . $ourMenu->alias)
                . ' WHERE ' . $db->quoteName('id') . ' = ' . (int)$ourMenu->id
            )->execute();

            try { (new \Joomla\CMS\Table\Menu($db))->rebuild(); } catch (\Exception $e) {}

        } catch (\Exception $e) {}
    }

    private function findParentId($db): int
    {
        $id = (int) $db->setQuery(
            $db->getQuery(true)->select('id')->from($db->quoteName('#__menu'))
                ->where($db->quoteName('alias') . ' = ' . $db->quote('rentalotplus'))
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('level') . ' = 1')
        )->loadResult();
        if ($id) return $id;

        $extId = (int) $db->setQuery(
            $db->getQuery(true)->select('extension_id')->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
        )->loadResult();

        if ($extId) {
            $id = (int) $db->setQuery(
                $db->getQuery(true)->select('id')->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('component_id') . ' = ' . $extId)
                    ->where($db->quoteName('client_id') . ' = 1')
                    ->where($db->quoteName('level') . ' = 1')
            )->loadResult();
            if ($id) return $id;
        }

        return (int) $db->setQuery(
            $db->getQuery(true)->select('id')->from($db->quoteName('#__menu'))
                ->where('LOWER(' . $db->quoteName('title') . ') LIKE ' . $db->quote('%rentalot%'))
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('level') . ' = 1')->order('id ASC')
        )->loadResult();
    }
}
