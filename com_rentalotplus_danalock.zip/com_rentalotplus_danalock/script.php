<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;

/**
 * Klassennamen-Konvention für Joomla 5 Install-Scripts:
 * com_ELEMENTNAME + InstallerScript (ohne Namespace, direkt im Wurzelverzeichnis)
 */
// phpcs:disable PSR1.Classes.ClassDeclaration
class Com_Rentalotplus_DanalockInstallerScript
{
    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if (!in_array($type, ['install', 'update'])) {
            return true;
        }

        $app = Factory::getApplication();

        try {
            $db = Factory::getDbo();

            // Unsere extension_id
            $ourExtId = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select('extension_id')
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus_danalock'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
            )->loadResult();

            if (!$ourExtId) {
                $app->enqueueMessage('Danalock: Eigene extension_id nicht gefunden.', 'warning');
                return true;
            }

            // Unseren Menüeintrag finden
            $ourMenu = $db->setQuery(
                $db->getQuery(true)
                    ->select(['id', 'alias', 'parent_id'])
                    ->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('component_id') . ' = ' . $ourExtId)
                    ->where($db->quoteName('client_id') . ' = 1')
            )->loadObject();

            if (!$ourMenu) {
                $app->enqueueMessage('Danalock: Eigener Menüeintrag nicht gefunden (ext_id=' . $ourExtId . ').', 'warning');
                return true;
            }

            // Rentalot-Plus-Hauptmenüeintrag suchen (3 Methoden)
            $parentId = $this->findParentId($db);

            if (!$parentId) {
                $app->enqueueMessage('Danalock: Rentalot-Plus-Menüeintrag nicht gefunden.', 'warning');
                return true;
            }

            if ((int)$ourMenu->parent_id === $parentId) {
                $app->enqueueMessage('Danalock: Menüpunkt bereits korrekt eingeordnet.', 'message');
                return true;
            }

            // Parent-Pfad holen
            $parentPath = (string) $db->setQuery(
                $db->getQuery(true)
                    ->select('path')
                    ->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('id') . ' = ' . $parentId)
            )->loadResult();

            $newPath = trim($parentPath, '/') . '/' . $ourMenu->alias;

            // Direktes UPDATE
            $db->setQuery(
                'UPDATE ' . $db->quoteName('#__menu')
                . ' SET '
                . $db->quoteName('parent_id') . ' = ' . $parentId . ', '
                . $db->quoteName('level') . ' = 2, '
                . $db->quoteName('path') . ' = ' . $db->quote($newPath)
                . ' WHERE ' . $db->quoteName('id') . ' = ' . (int)$ourMenu->id
            )->execute();

            // Nested-Set neu aufbauen
            try {
                $table = new \Joomla\CMS\Table\Menu($db);
                $table->rebuild();
            } catch (\Exception $e) {
                // Nicht kritisch
            }

            $app->enqueueMessage(
                '✅ Danalock PIN-Verwaltung wurde erfolgreich unter Rentalot Plus eingeordnet.',
                'message'
            );

        } catch (\Exception $e) {
            $app->enqueueMessage(
                'Danalock Installer Fehler: ' . $e->getMessage(),
                'error'
            );
        }

        return true;
    }

    private function findParentId($db): int
    {
        // Methode 1: alias = 'rentalotplus', level = 1
        $id = (int) $db->setQuery(
            $db->getQuery(true)
                ->select('id')
                ->from($db->quoteName('#__menu'))
                ->where($db->quoteName('alias') . ' = ' . $db->quote('rentalotplus'))
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('level') . ' = 1')
        )->loadResult();
        if ($id) return $id;

        // Methode 2: component_id von com_rentalotplus
        $extId = (int) $db->setQuery(
            $db->getQuery(true)
                ->select('extension_id')
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
        )->loadResult();

        if ($extId) {
            $id = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select('id')
                    ->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('component_id') . ' = ' . $extId)
                    ->where($db->quoteName('client_id') . ' = 1')
                    ->where($db->quoteName('level') . ' = 1')
            )->loadResult();
            if ($id) return $id;
        }

        // Methode 3: title LIKE '%rentalot%'
        return (int) $db->setQuery(
            $db->getQuery(true)
                ->select('id')
                ->from($db->quoteName('#__menu'))
                ->where('LOWER(' . $db->quoteName('title') . ') LIKE ' . $db->quote('%rentalot%'))
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('level') . ' = 1')
                ->order('id ASC')
        )->loadResult();
    }
}
