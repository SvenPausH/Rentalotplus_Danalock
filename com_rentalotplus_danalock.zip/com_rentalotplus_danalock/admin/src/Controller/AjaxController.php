<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\Component\RentalotplusDanalock\Administrator\Helper\DanalockConfig;
use Joomla\Component\RentalotplusDanalock\Administrator\Helper\DanalockHelper;

/**
 * Verarbeitet alle AJAX-Anfragen.
 * URL-Schema: index.php?option=com_rentalotplus_danalock&task=ajax.TASKNAME&format=json
 */
class AjaxController extends BaseController
{
    public function execute($task): void
    {
        $app    = Factory::getApplication();
        $helper = new DanalockHelper(DanalockConfig::getInstance());

        // CSRF-Schutz: Token muss im Request vorhanden sein
        if (!$this->checkToken('request')) {
            $this->sendJson(['success' => false, 'error' => 'Ungültiges Sicherheitstoken']);
            return;
        }

        // Task kommt als "ajax.taskname" – Prefix entfernen
        $action = str_replace('ajax.', '', $task);

        switch ($action) {
            case 'get_bookings':
                $this->sendJson($helper->getBookings());
                break;

            case 'save_booking_pin':
                $this->sendJson($helper->saveBookingPin(
                    $app->input->getInt('booking_id', 0),
                    $app->input->getInt('identifier', 0),
                    $app->input->get('pin', '', 'string'),
                    $app->input->get('checkin_time', '16:00', 'string'),
                    $app->input->get('checkout_time', '10:00', 'string')
                ));
                break;

            case 'delete_pin':
                $this->sendJson($helper->deletePin(
                    $app->input->getInt('identifier', 0),
                    $app->input->get('device', '', 'string')
                ));
                break;

            case 'get_pins':
                $this->sendJson($helper->getPins(
                    $app->input->get('device', '', 'string')
                ));
                break;

            case 'lock_status':
                $this->sendJson($helper->getLockStatus(
                    $app->input->get('device', '', 'string')
                ));
                break;

            case 'get_log':
                $this->sendJson($helper->getLogEntries(
                    $app->input->getInt('limit', 50)
                ));
                break;

            case 'clear_log':
                $this->sendJson($helper->clearLog());
                break;

            default:
                $this->sendJson(['success' => false, 'error' => 'Unbekannter Task: ' . $action]);
        }
    }

    private function sendJson(array $data): void
    {
        $app = Factory::getApplication();
        $app->setHeader('Content-Type', 'application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        $app->close();
    }
}
