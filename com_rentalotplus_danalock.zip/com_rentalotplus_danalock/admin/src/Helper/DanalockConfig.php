<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;

/**
 * Liest die Konfiguration aus den Komponenten-Parametern.
 * Das Passwort wird verschlüsselt in der Datenbank gespeichert.
 *
 * Verschlüsselung: AES-256-CBC mit dem Joomla-Secret als Schlüssel.
 * Das Joomla-Secret liegt in configuration.php ($secret) und ist
 * nur auf dem Server bekannt – ein Datenbankdump allein reicht nicht
 * um das Passwort zu entschlüsseln.
 */
class DanalockConfig
{
    private static ?self $instance = null;
    private \Joomla\Registry\Registry $params;
    private array $unitMapping = [];

    // Präfix um verschlüsselte Werte von Klartextwerten zu unterscheiden
    private const ENC_PREFIX = 'ENC:';

    private function __construct()
    {
        $this->params = ComponentHelper::getParams('com_rentalotplus_danalock');

        // Unit-Mapping parsen: eine Zeile pro Haus, Format "unit_id:MAC-Adresse"
        foreach (explode("\n", $this->params->get('unit_mapping', '')) as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, ':') === false) {
                continue;
            }
            $pos    = strpos($line, ':');
            $unitId = trim(substr($line, 0, $pos));
            $mac    = trim(substr($line, $pos + 1));
            if ($unitId !== '' && $mac !== '') {
                $this->unitMapping[$unitId] = $mac;
            }
        }
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /** Generischer Zugriff auf beliebige Parameter */
    public function getParam(string $key, mixed $default = null): mixed
    {
        return $this->params->get($key, $default);
    }

    public function getEmail(): string           { return $this->params->get('danalock_email', ''); }
    public function getDefaultDevice(): string   { return $this->params->get('danalock_device', ''); }
    public function getDefaultCheckin(): string  { return $this->params->get('default_checkin_time', '16:00'); }
    public function getDefaultCheckout(): string { return $this->params->get('default_checkout_time', '10:00'); }
    public function isDebugEnabled(): bool       { return (bool) $this->params->get('debug_enabled', 0); }
    public function getDebugMax(): int           { return (int) $this->params->get('debug_max_entries', 50); }
    public function getUnitMapping(): array      { return $this->unitMapping; }

    /**
     * Gibt das entschlüsselte Passwort zurück.
     * Ist der gespeicherte Wert noch Klartext (kein ENC:-Präfix),
     * wird er direkt zurückgegeben – Rückwärtskompatibilität.
     */
    public function getPassword(): string
    {
        $stored = $this->params->get('danalock_password', '');
        if ($stored === '') {
            return '';
        }
        if (str_starts_with($stored, self::ENC_PREFIX)) {
            return self::decrypt(substr($stored, strlen(self::ENC_PREFIX)));
        }
        // Klartext (noch nicht verschlüsselt gespeichert) – direkt zurückgeben
        return $stored;
    }

    /** Gibt die MAC-Adresse für eine unit_id zurück */
    public function getDeviceForUnit(int $unitId): string
    {
        return $this->unitMapping[$unitId] ?? $this->getDefaultDevice();
    }

    // =========================================================================
    // Verschlüsselung (AES-256-CBC, Schlüssel = Joomla-Secret)
    // =========================================================================

    /**
     * Verschlüsselt einen Wert für die Speicherung in der DB.
     * Gibt den Wert mit ENC:-Präfix zurück.
     */
    public static function encrypt(string $plaintext): string
    {
        if ($plaintext === '') {
            return '';
        }

        $key    = self::getKey();
        $iv     = random_bytes(16);
        $cipher = openssl_encrypt($plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);

        if ($cipher === false) {
            // Verschlüsselung fehlgeschlagen – Klartext zurückgeben
            return $plaintext;
        }

        return self::ENC_PREFIX . base64_encode($iv . $cipher);
    }

    /**
     * Entschlüsselt einen mit encrypt() verschlüsselten Wert.
     */
    public static function decrypt(string $encoded): string
    {
        if ($encoded === '') {
            return '';
        }

        try {
            $key  = self::getKey();
            $data = base64_decode($encoded, strict: true);
            if ($data === false || strlen($data) < 17) {
                return '';
            }

            $iv         = substr($data, 0, 16);
            $ciphertext = substr($data, 16);
            $plain      = openssl_decrypt($ciphertext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);

            return $plain !== false ? $plain : '';
        } catch (\Throwable $e) {
            return '';
        }
    }

    /**
     * Leitet einen 32-Byte-Schlüssel aus dem Joomla-Secret ab.
     * Das Secret liegt in configuration.php und ist nicht in der DB.
     */
    private static function getKey(): string
    {
        $config = Factory::getApplication()->get('secret', '');
        if ($config === '') {
            // Fallback: Joomla-Konfigurationsobjekt direkt laden
            $jConfig = new \JConfig();
            $config  = $jConfig->secret ?? '';
        }
        // SHA-256 liefert immer genau 32 Bytes
        return hash('sha256', $config, binary: true);
    }
}
