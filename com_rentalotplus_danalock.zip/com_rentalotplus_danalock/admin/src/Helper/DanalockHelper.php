<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;

/**
 * Kapselt alle Danalock Bridge API-Aufrufe sowie den Datenbankzugriff
 * auf Rentalot Plus Buchungen und die eigenen PIN/Log-Tabellen.
 *
 * API-Flow (asynchron):
 *   1. POST /bridge/v1/execute  → gibt job_id zurück
 *   2. ~7 Sekunden warten
 *   3. POST /bridge/v1/poll mit job_id → Ergebnis
 *
 * Authentifizierung: OAuth2 Password Grant gegen api.danalock.com
 * Token wird in der Joomla-Session gecacht (1 Stunde).
 */
class DanalockHelper
{
    // Danalock API-Endpunkte
    private const TOKEN_URL  = 'https://api.danalock.com/oauth2/token';
    private const BRIDGE_URL = 'https://bridge.danalockservices.com/bridge/v1/execute';
    private const POLL_URL   = 'https://bridge.danalockservices.com/bridge/v1/poll';
    private const POLL_WAIT  = 7; // Sekunden zwischen execute und poll

    // Eigene Datenbanktabellen (nutzen rentalot_plus_ Präfix)
    private const TABLE_PINS = '#__rentalot_plus_danalock_pins';
    private const TABLE_LOG  = '#__rentalot_plus_danalock_log';

    private DanalockConfig $config;

    public function __construct(DanalockConfig $config)
    {
        $this->config = $config;
    }

    // =========================================================================
    // Buchungen
    // =========================================================================

    /**
     * Lädt alle aktuellen und zukünftigen Buchungen aus Rentalot Plus
     * und ergänzt gespeicherte PIN-Daten aus unserer eigenen Tabelle.
     */
    public function getBookings(): array
    {
        try {
            $db    = Factory::getDbo();
            $today = date('Y-m-d');

            $bookings = $db->setQuery(
                $db->getQuery(true)
                    ->select(['b.id', 'b.unit_id', 'b.date_from', 'b.date_to',
                              'b.state', 'b.forenames', 'b.surname'])
                    ->from($db->quoteName('#__rentalot_plus_bookings', 'b'))
                    ->where('b.state IN (0, 1)')          // 0=Reserviert, 1=Gebucht
                    ->where('b.date_to >= ' . $db->quote($today))
                    ->order('b.date_from ASC')
            )->loadAssocList();

            // Gespeicherte PINs als Map laden (booking_id → PIN-Daten)
            $pinData = $db->setQuery(
                $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName(self::TABLE_PINS))
            )->loadAssocList('booking_id');

            foreach ($bookings as &$b) {
                $pin = $pinData[$b['id']] ?? null;
                $b['pin_identifier'] = $pin ? (int)$pin['pin_identifier'] : null;
                $b['pin_code']       = $pin['pin_code']      ?? '';
                $b['checkin_time']   = $pin['checkin_time']  ?? $this->config->getDefaultCheckin();
                $b['checkout_time']  = $pin['checkout_time'] ?? $this->config->getDefaultCheckout();
                $b['device']         = $this->config->getDeviceForUnit((int)$b['unit_id']);
            }
            unset($b);

            return ['success' => true, 'bookings' => $bookings];

        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // =========================================================================
    // PIN-Verwaltung
    // =========================================================================

    /**
     * Speichert PIN-Daten in der DB und sendet den PIN ans Schloss.
     */
    public function saveBookingPin(int $bookingId, int $identifier, string $pin,
                                   string $checkin, string $checkout): array
    {
        // Eingaben validieren
        if ($bookingId <= 0 || $identifier < 1 || $identifier > 20) {
            return ['success' => false, 'error' => 'Ungültige Parameter'];
        }
        if (!preg_match('/^\d{4,10}$/', $pin)) {
            return ['success' => false, 'error' => 'Ungültiger PIN: nur Ziffern, 4–10 Stellen'];
        }
        if (!preg_match('/^\d{2}:\d{2}$/', $checkin) || !preg_match('/^\d{2}:\d{2}$/', $checkout)) {
            return ['success' => false, 'error' => 'Ungültiges Zeitformat (HH:MM erwartet)'];
        }

        // In DB speichern (INSERT oder UPDATE)
        try {
            $db  = Factory::getDbo();
            $obj = (object)[
                'booking_id'     => $bookingId,
                'pin_identifier' => $identifier,
                'pin_code'       => $pin,
                'checkin_time'   => $checkin,
                'checkout_time'  => $checkout,
                'last_updated'   => date('Y-m-d H:i:s'),
            ];

            $existingId = $db->setQuery(
                $db->getQuery(true)
                    ->select('id')
                    ->from($db->quoteName(self::TABLE_PINS))
                    ->where('booking_id = ' . $bookingId)
            )->loadResult();

            if ($existingId) {
                $obj->id = $existingId;
                $db->updateObject(self::TABLE_PINS, $obj, 'id');
            } else {
                $db->insertObject(self::TABLE_PINS, $obj);
            }
        } catch (\Exception $e) {
            return ['success' => false, 'error' => 'Datenbankfehler: ' . $e->getMessage()];
        }

        // Gerät für diese Buchung ermitteln
        $device = $this->config->getDefaultDevice();
        try {
            $unitId = Factory::getDbo()->setQuery(
                Factory::getDbo()->getQuery(true)
                    ->select('unit_id')
                    ->from(Factory::getDbo()->quoteName('#__rentalot_plus_bookings'))
                    ->where('id = ' . $bookingId)
            )->loadResult();
            if ($unitId) {
                $device = $this->config->getDeviceForUnit((int)$unitId);
            }
        } catch (\Exception $e) {
            // Fallback auf Standard-Gerät
        }

        // PIN ans Schloss senden
        $token = $this->getOAuthToken();
        if (!$token) {
            return ['success' => true, 'saved' => true, 'sent' => false,
                    'error'   => 'PIN gespeichert, aber Token-Fehler – Zugangsdaten prüfen'];
        }

        $result  = $this->executeBridgeCommand(
            $token, $device,
            'afi.pin-codes.set-pin-code',
            [(string)$identifier, 'Enabled', $pin],
            'PIN setzen: Buchung #' . $bookingId . ', Slot ' . $identifier
        );
        $success = ($result['result']['result']['afi_status'] ?? -1) === 0;

        return ['success' => true, 'saved' => true, 'sent' => $success, 'data' => $result];
    }

    /**
     * Löscht einen PIN-Slot am Schloss (setzt ihn auf "Cleared").
     */
    public function deletePin(int $identifier, string $device = ''): array
    {
        if ($identifier < 1 || $identifier > 20) {
            return ['success' => false, 'error' => 'Ungültiger Slot (1–20)'];
        }
        if (empty($device)) {
            $device = $this->config->getDefaultDevice();
        }

        $token = $this->getOAuthToken();
        if (!$token) {
            return ['success' => false, 'error' => 'Token-Fehler'];
        }

        $result = $this->executeBridgeCommand(
            $token, $device,
            'afi.pin-codes.set-pin-code',
            [(string)$identifier, 'Cleared', '0000'],
            'PIN löschen: Slot ' . $identifier
        );

        return ['success' => true, 'data' => $result];
    }

    /**
     * Liest alle 20 PIN-Slots vom Schloss und ergänzt DB-Daten (Gast, Uhrzeiten).
     */
    public function getPins(string $device = ''): array
    {
        if (empty($device)) {
            $device = $this->config->getDefaultDevice();
        }

        $token = $this->getOAuthToken();
        if (!$token) {
            return ['success' => false, 'error' => 'Token-Fehler – Zugangsdaten unter Optionen prüfen'];
        }

        $result = $this->executeBridgeCommand(
            $token, $device,
            'afi.pin-codes.get-pin-codes',
            ['20'],
            'Alle PINs auslesen'
        );

        // DB-Daten (Gast, Uhrzeiten) pro Slot laden
        $dbPins = [];
        try {
            $db   = Factory::getDbo();
            $rows = $db->setQuery(
                $db->getQuery(true)
                    ->select(['p.pin_identifier', 'p.checkin_time', 'p.checkout_time',
                               'b.forenames', 'b.surname'])
                    ->from($db->quoteName(self::TABLE_PINS, 'p'))
                    ->join('LEFT',
                        $db->quoteName('#__rentalot_plus_bookings', 'b') .
                        ' ON b.id = p.booking_id')
            )->loadAssocList();

            foreach ($rows as $row) {
                $dbPins[(int)$row['pin_identifier']] = [
                    'guest_name'    => trim($row['forenames'] . ' ' . $row['surname']),
                    'checkin_time'  => $row['checkin_time'],
                    'checkout_time' => $row['checkout_time'],
                ];
            }
        } catch (\Exception $e) {
            // DB-Fehler: Slots trotzdem anzeigen, DB-Spalten bleiben leer
        }

        return ['success' => true, 'data' => $result, 'db_pins' => $dbPins];
    }

    /**
     * Fragt den aktuellen Schloss-Status ab (Locked / Unlocked).
     */
    public function getLockStatus(string $device = ''): array
    {
        if (empty($device)) {
            $device = $this->config->getDefaultDevice();
        }

        $token = $this->getOAuthToken();
        if (!$token) {
            return ['success' => false, 'error' => 'Token-Fehler'];
        }

        $result = $this->executeBridgeCommand(
            $token, $device,
            'afi.lock.get-state',
            [],
            'Schloss-Status abfragen'
        );

        return ['success' => true, 'data' => $result];
    }

    // =========================================================================
    // Debug-Log
    // =========================================================================

    /** Gibt die letzten Log-Einträge zurück */
    public function getLogEntries(int $limit = 50): array
    {
        try {
            $db      = Factory::getDbo();
            $entries = $db->setQuery(
                $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName(self::TABLE_LOG))
                    ->order('id DESC'),
                0, max(1, min($limit, 500))
            )->loadAssocList();

            return ['success' => true, 'entries' => $entries];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /** Löscht alle Log-Einträge */
    public function clearLog(): array
    {
        try {
            $db     = Factory::getDbo();
            $table  = str_replace('#__', $db->getPrefix(), self::TABLE_LOG);
            $db->setQuery('TRUNCATE TABLE ' . $db->quoteName($table))->execute();
            return ['success' => true];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // =========================================================================
    // Danalock Bridge API (intern)
    // =========================================================================

    /**
     * Holt ein OAuth2-Token (Password Grant).
     * Token wird in der Joomla-Session gecacht um unnötige API-Aufrufe zu vermeiden.
     */
    public function getOAuthToken(): ?string
    {
        $session = Factory::getApplication()->getSession();
        $token   = $session->get('danalock_token');
        $expiry  = $session->get('danalock_token_exp', 0);

        // Gecachten Token verwenden wenn noch 60+ Sekunden gültig
        if ($token && time() < $expiry - 60) {
            return $token;
        }

        $this->dbLog('AUTH', 'Token-Anfrage', ['user' => $this->config->getEmail()]);

        $response = $this->httpPost(
            self::TOKEN_URL,
            http_build_query([
                'grant_type'    => 'password',
                'username'      => $this->config->getEmail(),
                'password'      => $this->config->getPassword(),
                'client_id'     => 'danalock-web',
                'client_secret' => '',
                'scope'         => '',
            ]),
            ['Content-Type: application/x-www-form-urlencoded']
        );

        if (!$response || !isset($response['access_token'])) {
            $this->dbLog('AUTH_ERROR', 'Token-Anfrage fehlgeschlagen', $response ?? []);
            Log::add('Danalock Token-Fehler: ' . json_encode($response), Log::ERROR, 'com_rentalotplus_danalock');
            return null;
        }

        $token  = $response['access_token'];
        $expiry = time() + ($response['expires_in'] ?? 3600);
        $session->set('danalock_token', $token);
        $session->set('danalock_token_exp', $expiry);

        $this->dbLog('AUTH_OK', 'Token erhalten', ['expires_in' => $response['expires_in'] ?? 3600]);
        return $token;
    }

    /**
     * Führt einen Bridge-Befehl aus (asynchron: execute → warten → poll).
     */
    private function executeBridgeCommand(string $token, string $device,
                                          string $operation, array $arguments,
                                          string $description = ''): array
    {
        $body = ['device' => $device, 'operation' => $operation];
        if (!empty($arguments)) {
            $body['arguments'] = $arguments;
        }

        $this->dbLog('EXECUTE', $description ?: $operation, [
            'device'    => $device,
            'operation' => $operation,
            'arguments' => $arguments,
        ]);

        $response = $this->httpPost(
            self::BRIDGE_URL,
            json_encode($body),
            ['Content-Type: application/json', 'Authorization: Bearer ' . $token]
        );

        if (!$response || !isset($response['id'])) {
            $this->dbLog('EXECUTE_ERROR', 'Keine Job-ID erhalten', ['response' => $response]);
            return ['error' => 'Keine Job-ID erhalten', 'raw' => $response];
        }

        $jobId = $response['id'];
        $this->dbLog('JOB_ID', 'Job-ID erhalten, warte ' . self::POLL_WAIT . 's', ['job_id' => $jobId]);

        sleep(self::POLL_WAIT);

        $poll = $this->httpPost(
            self::POLL_URL,
            json_encode(['id' => $jobId]),
            ['Content-Type: application/json', 'Authorization: Bearer ' . $token]
        );

        $this->dbLog('POLL_RESULT', $description ?: $operation, [
            'job_id' => $jobId,
            'result' => $poll,
        ]);

        return $poll ?? ['error' => 'Poll-Antwort leer', 'job_id' => $jobId];
    }

    /**
     * HTTP POST via cURL, gibt dekodiertes JSON zurück.
     */
    private function httpPost(string $url, string|array $body, array $headers): ?array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $raw      = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($error) {
            Log::add('cURL-Fehler: ' . $error, Log::ERROR, 'com_rentalotplus_danalock');
            return null;
        }

        $data = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            Log::add('JSON-Fehler (HTTP ' . $httpCode . '): ' . $raw, Log::ERROR, 'com_rentalotplus_danalock');
            return null;
        }

        return $data;
    }

    // =========================================================================
    // Internes Debug-Logging
    // =========================================================================

    /**
     * Schreibt einen Eintrag in die Log-Tabelle (nur wenn Debug aktiviert).
     * Fehler im Logging dürfen die Hauptfunktion nicht unterbrechen.
     */
    private function dbLog(string $level, string $message, array $context = []): void
    {
        if (!$this->config->isDebugEnabled()) {
            return;
        }

        try {
            $db = Factory::getDbo();
            $db->insertObject(self::TABLE_LOG, (object)[
                'created_at' => date('Y-m-d H:i:s'),
                'level'      => $level,
                'message'    => $message,
                'context'    => json_encode($context, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
            ]);

            // Älteste Einträge löschen wenn Maximum überschritten
            $count = (int) $db->setQuery(
                'SELECT COUNT(*) FROM ' . $db->quoteName(self::TABLE_LOG)
            )->loadResult();

            $max = $this->config->getDebugMax();
            if ($count > $max) {
                $db->setQuery(
                    'DELETE FROM ' . $db->quoteName(self::TABLE_LOG) .
                    ' ORDER BY id ASC LIMIT ' . ($count - $max)
                )->execute();
            }
        } catch (\Exception $e) {
            // Logging-Fehler still ignorieren
        }
    }
}
