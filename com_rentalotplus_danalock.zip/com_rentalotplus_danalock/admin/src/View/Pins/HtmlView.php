<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\View\Pins;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\Component\RentalotplusDanalock\Administrator\Helper\DanalockConfig;

class HtmlView extends BaseHtmlView
{
    public DanalockConfig $config;

    public function display($tpl = null): void
    {
        $this->config = DanalockConfig::getInstance();

        ToolbarHelper::title('Danalock PIN-Verwaltung', 'lock');
        ToolbarHelper::preferences('com_rentalotplus_danalock');

        parent::display($tpl);
    }
}
