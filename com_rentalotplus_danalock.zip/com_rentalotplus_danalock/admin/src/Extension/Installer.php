<?php
namespace Joomla\Component\RentalotplusDanalock\Administrator\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;

/**
 * Install-Script für com_rentalotplus_danalock.
 * Ordnet den Menüpunkt als Kind von Rentalot Plus ein.
 */
class Installer
{
    public function postflight(string $type, InstallerAdapter $adapter): void
    {
        if (!in_array($type, ['install', 'update'])) {
            return;
        }

        $app = Factory::getApplication();

        try {
            $db = Factory::getDbo();

            // Schritt 1: Rentalot-Plus-Hauptmenüeintrag finden (mehrere Suchmethoden)
            $parentId = $this->findRentalotParentId($db);

            if (!$parentId) {
                $app->enqueueMessage(
                    'Danalock Installer: Rentalot-Plus-Menüeintrag nicht gefunden – '
                    . 'Menüpunkt bleibt eigenständig.',
                    'warning'
                );
                return;
            }

            // Schritt 2: Unseren Menüeintrag finden (über extension_id)
            $ourExtId = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select('extension_id')
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus_danalock'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
            )->loadResult();

            $app->enqueueMessage('Danalock Installer: extension_id=' . $ourExtId . ', parentId=' . $parentId, 'notice');

            if (!$ourExtId) {
                $app->enqueueMessage('Danalock Installer: Eigene extension_id nicht gefunden.', 'warning');
                return;
            }

            // Schritt 3: Unseren Menüeintrag in #__menu suchen
            $ourMenuId = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select('id')
                    ->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('component_id') . ' = ' . $ourExtId)
                    ->where($db->quoteName('client_id') . ' = 1')
            )->loadResult();

            $app->enqueueMessage('Danalock Installer: ourMenuId=' . $ourMenuId, 'notice');

            if (!$ourMenuId) {
                $app->enqueueMessage('Danalock Installer: Eigener Menüeintrag nicht gefunden.', 'warning');
                return;
            }

            // Schritt 4: path des Parents laden
            $parentPath = (string) $db->setQuery(
                $db->getQuery(true)
                    ->select('path')
                    ->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('id') . ' = ' . $parentId)
            )->loadResult();

            $ourAlias = (string) $db->setQuery(
                $db->getQuery(true)
                    ->select('alias')
                    ->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('id') . ' = ' . $ourMenuId)
            )->loadResult();

            $newPath = trim($parentPath, '/') . '/' . $ourAlias;

            // Schritt 5: Direktes UPDATE ohne ORM
            $db->setQuery(
                'UPDATE ' . $db->quoteName('#__menu') . ' SET '
                . $db->quoteName('parent_id') . ' = ' . $parentId . ', '
                . $db->quoteName('level') . ' = 2, '
                . $db->quoteName('path') . ' = ' . $db->quote($newPath)
                . ' WHERE ' . $db->quoteName('id') . ' = ' . $ourMenuId
            )->execute();

            $affected = $db->getAffectedRows();
            $app->enqueueMessage(
                'Danalock Installer: UPDATE ausgeführt, betroffene Zeilen: ' . $affected,
                'notice'
            );

            // Schritt 6: lft/rgt Nested-Set neu aufbauen
            $db->setQuery('CALL ' . $db->quoteName('') . '')->execute();
            $this->rebuildNestedSet($db);

            $app->enqueueMessage(
                'Danalock PIN-Verwaltung wurde erfolgreich unter Rentalot Plus eingeordnet.',
                'message'
            );

        } catch (\Exception $e) {
            $app->enqueueMessage(
                'Danalock Installer Fehler: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(),
                'error'
            );
        }
    }

    /**
     * Sucht die ID des Rentalot-Plus-Hauptmenüeintrags mit mehreren Fallbacks.
     */
    private function findRentalotParentId($db): int
    {
        // Methode 1: über alias
        $id = (int) $db->setQuery(
            $db->getQuery(true)
                ->select('id')
                ->from($db->quoteName('#__menu'))
                ->where($db->quoteName('alias') . ' = ' . $db->quote('rentalotplus'))
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('level') . ' = 1')
        )->loadResult();
        if ($id) return $id;

        // Methode 2: über component_id aus #__extensions
        $extId = (int) $db->setQuery(
            $db->getQuery(true)
                ->select('extension_id')
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
        )->loadResult();

        if ($extId) {
            $id = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select('id')
                    ->from($db->quoteName('#__menu'))
                    ->where($db->quoteName('component_id') . ' = ' . $extId)
                    ->where($db->quoteName('client_id') . ' = 1')
                    ->where($db->quoteName('level') . ' = 1')
                    ->order('id ASC')
            )->loadResult();
            if ($id) return $id;
        }

        // Methode 3: über title LIKE '%rentalot%', level=1
        $id = (int) $db->setQuery(
            $db->getQuery(true)
                ->select('id')
                ->from($db->quoteName('#__menu'))
                ->where('LOWER(' . $db->quoteName('title') . ') LIKE ' . $db->quote('%rentalot%'))
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('level') . ' = 1')
                ->order('id ASC')
        )->loadResult();

        return $id;
    }

    /**
     * Baut den Nested-Set-Baum für den Administrator-Menü-Baum neu auf.
     */
    private function rebuildNestedSet($db): void
    {
        try {
            $table = new \Joomla\CMS\Table\Menu(
                $db
            );
            $table->rebuild();
        } catch (\Exception $e) {
            // Nested-Set-Fehler sind nicht kritisch – Menüpunkt funktioniert trotzdem
        }
    }
}
