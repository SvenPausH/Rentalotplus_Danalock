<?php
namespace Joomla\Plugin\System\RentalotplusDanalock\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\Component\RentalotplusDanalock\Administrator\Helper\DanalockConfig;

/**
 * Verschlüsselt das Danalock-Passwort automatisch wenn die Komponenten-Optionen
 * gespeichert werden.
 *
 * Ablauf:
 *   1. Admin speichert Optionen in com_rentalotplus_danalock
 *   2. onExtensionAfterSave feuert
 *   3. Plugin prüft ob Passwort als Klartext vorliegt
 *   4. Falls ja: verschlüsseln und direkt in DB zurückschreiben
 */
class RentalotplusDanalock extends CMSPlugin
{
    /**
     * Wird nach dem Speichern einer Erweiterung aufgerufen.
     * Wir reagieren nur auf com_rentalotplus_danalock.
     */
    public function onExtensionAfterSave(string $context, object $table, bool $isNew): void
    {
        // Nur für unsere Komponente
        if ($context !== 'com_config.component') {
            return;
        }

        // Geladene Erweiterung prüfen
        $element = $table->element ?? $table->name ?? '';
        if ($element !== 'com_rentalotplus_danalock') {
            return;
        }

        // Aktuelle Parameter laden
        $params = ComponentHelper::getParams('com_rentalotplus_danalock');
        $password = $params->get('danalock_password', '');

        // Nur verschlüsseln wenn noch kein ENC:-Präfix vorhanden
        if ($password === '' || str_starts_with($password, 'ENC:')) {
            return;
        }

        // Passwort verschlüsseln
        $encrypted = DanalockConfig::encrypt($password);

        // Zurück in die Datenbank schreiben
        $params->set('danalock_password', $encrypted);

        $db = $this->getDatabase();
        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($params->toString()))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_rentalotplus_danalock'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
        )->execute();
    }
}
